import { Component } from '@angular/core';

@Component({
  templateUrl: 'app/home/home.component.html'
})
export class HomeComponent {

}
