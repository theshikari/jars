function AnimationCtrl($scope) {
  $scope.checked = true;
}

AnimationCtrl.$inject = ['$scope'];
