describe('smoke jasmine tests', function() {
  it('should do some dummy test', function() {
    expect(1).toBe(1);
  });
});
