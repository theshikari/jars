describe('category', function() {
  it('name', function() {
    browser.get('index.html');
    browser.waitForAngular();
  });
});
